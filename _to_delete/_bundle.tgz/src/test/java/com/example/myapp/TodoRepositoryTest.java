package com.example.myapp;

import com.example.myapp.entity.Priority;
import com.example.myapp.entity.Todo;
import com.example.myapp.repository.TodoRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class TodoRepositoryTest {

    @Autowired
    private TodoRepository repository;

    private Todo newTodo(String title, boolean completed, Priority priority) {
        Todo todo = new Todo();
        todo.setTitle(title);
        todo.setCompleted(completed);
        todo.setPriority(priority);
        return todo;
    }

    @Test
    void savesAndReadsBackTimestamps() {
        Todo saved = repository.save(newTodo("Buy milk", false, Priority.HIGH));
        assertThat(saved.getId()).isNotNull();
        assertThat(saved.getCreatedAt()).isNotNull();
        assertThat(saved.getUpdatedAt()).isNotNull();
    }

    @Test
    void searchFiltersByCompletedAndPriority() {
        repository.save(newTodo("Task A", false, Priority.HIGH));
        repository.save(newTodo("Task B", true, Priority.LOW));
        repository.save(newTodo("Task C", false, Priority.LOW));

        Page<Todo> onlyOpen = repository.search(false, null, null, PageRequest.of(0, 10));
        assertThat(onlyOpen.getTotalElements()).isEqualTo(2);

        Page<Todo> lowPriority = repository.search(null, Priority.LOW, null, PageRequest.of(0, 10));
        assertThat(lowPriority.getTotalElements()).isEqualTo(2);

        Page<Todo> byText = repository.search(null, null, "task a", PageRequest.of(0, 10));
        assertThat(byText.getTotalElements()).isEqualTo(1);
        assertThat(byText.getContent().get(0).getTitle()).isEqualTo("Task A");
    }
}
